# Databricks notebook source
# MAGIC %run "./utils"

# COMMAND ----------
from kensu.utils.kensu_provider import KensuProvider
token = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI3NhbW15IiwidG9rZW5faWQiOiI4NmYxMWU0Ni02NDk1LTRkNWItODhjZS01ODk1NTAxNDM0NzUiLCJhcHBncm91cF9pZCI6IjUyZTVkNDNjLTM0ZGYtNGRkZi1hM2Y3LTIwODU2Y2MzOWY2ZCIsIiRpbnRfcm9sZXMiOlsiYXBwIl0sImV4cCI6MTg4ODE0MTk2NiwiaWF0IjoxNTcyNzgxOTY2fQ.4CdaN9a80xc1ry6aT52MFxc33vb0nJVXX5TdGzdoJ7E"
kensu = KensuProvider().initKensu(api_url="https://api.sandbox.kensu.io", auth_token=token, init_context=True,offline_file_name='tr',report_to_file=True)

# COMMAND ----------

import kensu.pandas as pd
import datetime


# COMMAND ----------

def data_prep(data):
    import kensu.numpy as np
    import kensu.pandas as pd
    data['education'] = np.where(data['education'] == 'basic.9y', 'Basic', data['education'])
    data['education'] = np.where(data['education'] == 'basic.6y', 'Basic', data['education'])
    data['education'] = np.where(data['education'] == 'basic.4y', 'Basic', data['education'])

    cat = [i for i in
           ['job', 'marital', 'education', 'default', 'housing', 'loan', 'contact', 'month', 'day_of_week', 'poutcome']
           if i in data.columns]

    data_dummy = pd.get_dummies(data, columns=cat)

    features = [i for i in ['euribor3m', 'job_blue-collar', 'job_housemaid', 'marital_unknown',
                            'month_apr', 'month_aug', 'month_jul', 'month_jun', 'month_mar',
                            'month_may', 'month_nov', 'month_oct', "poutcome_success"] if i in data_dummy.columns]

    data_final = data_dummy[features]
    return data_final


# COMMAND ----------

# Generic



k = KensuProvider().instance()
timestamp = int(datetime.datetime(2021, 1, 1).timestamp() * 1000)
k.kensu_api.api_client.default_headers["X-Entity-Creation-Time"] = timestamp
k.timestamp = timestamp
'''
jan = pd.read_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/jan/data.csv')
jan_final = data_prep(jan)
# jan_final.to_csv('/dbfs/FileStore/tables/data/jan_matrix.csv',index=False)
'''
# COMMAND ----------

# jan_final = pd.read_csv('/dbfs/FileStore/tables/data/jan_matrix.csv')

# COMMAND ----------

import kensu.pickle as pk

model = pk.load(open('/Users/kensu/Customers/Kensu/Trial/demo/model_t2.cav', 'rb'))

# COMMAND ----------
"""
predictions = model.predict(jan_final)
jan['predictions'] = predictions
jan.to_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/jan/data_with_predictions.csv', index=False)
"""
# COMMAND ----------

i = 2
for el in ['apr']:
    # try:
    timestamp = int(datetime.datetime(2021, i, 1).timestamp() * 1000)
    i += 1
    k.kensu_api.api_client.default_headers["X-Entity-Creation-Time"] = timestamp
    k.timestamp = timestamp

    month = pd.read_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/%s/data.csv' % el)
    month_final = data_prep(month)
    predictions = model.predict(month_final)
    month['predictions'] = predictions
    month.to_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/%s/data_with_predictions.csv' % el, index=False)
    print('%s done' % el)
# except:

# print('Error in %s'%el)



