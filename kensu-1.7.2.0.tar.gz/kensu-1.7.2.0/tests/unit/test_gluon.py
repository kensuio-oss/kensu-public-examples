
ingestion_url = "https://playground-api.kensuapp.com"
ingestion_token = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI2dvb2dsZS1vYXV0aDJ8MTE0OTg0MzE2MTU2NTQ4MTczNzA5IiwidG9rZW5faWQiOiIxZTg3ZjE1NS1mNDBlLTQ2ZTctODlhZi1mNjIyN2Q3NzllNjAiLCJhcHBncm91cF9pZCI6IjY3ZGRiMGM2LTJiMWUtNDk1OS04YzU1LTNiZDg1ZjgxOTY1ZiIsIiRpbnRfcm9sZXMiOlsiYXBwIl0sImV4cCI6MTkzNjY4NTU4MSwiaWF0IjoxNjIxMzI1NTgxfQ.VRrZvitSPdtVcAK6JP263PSa_7-4JAEH8Z4OWTZVXoM"


from kensu.utils.kensu_provider import KensuProvider

import urllib3
urllib3.disable_warnings()

dam = KensuProvider().initKensu(api_url=ingestion_url, auth_token=ingestion_token, process_name='Test Gluon',
                            user_name='Sammy', code_location='https://gitlab.example.com', init_context=True, do_report=True,
                            report_to_file=False, offline_file_name='kensu-offline-custom-name.txt',
                            project_names=['Pandas'], pandas_support=True, sklearn_support=False,
                                tensorflow_support=False, bigquery_support=False,pyspark_support=False,
                         environment="Lab",mapping=True,report_in_mem=False,logical_naming='Folder')

"""
import pandas
import numpy
DS = pandas.read_csv('https://web.stanford.edu/class/archive/cs/cs109/cs109.1166/stuff/titanic.csv')
DS['na'] = numpy.nan

DS.to_csv('test_Set.csv',index=False)
"""

import kensu.pandas as pd
import kensu.numpy as np






#DS["Name_1"] = DS["Name"].str[-2:]
#DS["bu"] = DS["Name"].str[:-3]



#DS['Age'].replace(38, np.nan, inplace=True)

#SEX = DS["Sex"].astype("category").cat.codes.values

#DS["Sex"].astype("category").cat.codes.values

#DS['Age'] = np.where(DS["Sex"] == "female", DS['Age'].replace(38, np.nan), DS['Age'])


#d = DS["Sex"].astype("category").cat.codes.values

#d_un, d_counts = np.unique(d, return_counts=True)

#DS = DS.fillna(0)


#import numpy as np

#from gluonts.dataset.common import  ListDataset
#from gluonts.dataset.field_names import FieldName



import kensu.pandas as pd
import kensu.numpy as np


#DS = pd.read_csv('/Users/kensu/test/Source/official/kensu-py/tests/unit/test_Set.csv')
'''
age = DS.Age.values
f = ((age - age.mean(0)) / age.std(0))

(np.abs(((age - age.mean(0)) / age.std(0))) > 1).__class__

#np.savetxt('ok.txt',cde)

t =[]
r = age[3]

t.append(r)

#np.savetxt('ok2.txt',r)

import numpy
t[0].__class__


#DS["Name"].str[-2:]
'''

'''df = pd.read_csv('ttt.csv')
pd.DataFrame(df.to_records()).__class__


train_df=pd.read_json('{"2020-12-28":{"0":123,"1":123,"2":123}}')
df = pd.read_json('{"COD_ART_GAM":{"0":"3037846_NOR-SP_W006","1":"3038363_NOR-SP_W006","2":"6008477_NOR-SP_W006"},"DT_START":{"0":1609113600000,"1":1609113600000,"2":1609113600000},"COD_ART":{"0":"3037846","1":"3038363","2":"6008477"},"Indice":{"0":0.0,"1":0.0,"2":0.0},"COD_GAM":{"0":"NOR-SP","1":"NOR-SP","2":"NOR-SP"},"COD_SIT":{"0":"W006","1":"W006","2":"W006"},"COD_HIE_ART_001":{"0":123,"1":123,"2":123},"COD_HIE_ART_002":{"0":"123123","1":"123123","2":"123123"},"COD_HIE_ART_003":{"0":"123123123123","1":"123123123123","2":"123123123123"},"COD_HIE_ART_004":{"0":"123123123123123123123123","1":"123123123123123123123123","2":"123123123123123123123123"},"COD_GRP_MAR":{"0":"somestring","1":"somestring","2":"somestring"},"LIB_GRP_MAR":{"0":"somestring","1":"somestring","2":"somestring"},"LIB_HIE_ART_001":{"0":123,"1":123,"2":123},"LIB_HIE_ART_002":{"0":123,"1":123,"2":123},"LIB_HIE_ART_003":{"0":123,"1":123,"2":123},"LIB_HIE_ART_004":{"0":123,"1":123,"2":123},"LIB_HIE_ART_005":{"0":123,"1":123,"2":123},"LIB_HIE_ART_006":{"0":123,"1":123,"2":123},"COD_HIE_ART_005":{"0":"123123123123123123123123123","1":"123123123123123123123123123","2":"123123123123123123123123123"},"COD_HIE_ART_006":{"0":"123123123123123123123123123123123123123123123123123123","1":"123123123123123123123123123123123123123123123123123123","2":"123123123123123123123123123123123123123123123123123123"},"COD_MRQ":{"0":"somestring","1":"somestring","2":"somestring"},"PRX_ACH_NET_OA01":{"0":27.160320282,"1":27.160320282,"2":27.160320282},"COD_DEV_ACH_OA01":{"0":"PLN","1":"PLN","2":"PLN"},"COD_SAI":{"0":"somestring","1":"somestring","2":"somestring"},"COD_FOU_PCP":{"0":"somestring","1":"somestring","2":"somestring"},"DIA_PNE":{"0":123,"1":123,"2":123},"COD_STA_ART":{"0":"somestring","1":"somestring","2":"somestring"},"2020-12-28":{"0":123,"1":123,"2":123},"country":{"0":"SP","1":"SP","2":"SP"},"bu":{"0":"NOR","1":"NOR","2":"NOR"}}')
t=[]
t2=[]
prediction_length=12

import decimal as dc
dc.Decimal('0.00000')
df['Indice'] = dc.Decimal('0.00000')


for i in range(len(train_df.values)):
  print("i={}".format(str(i)))
  print("train_df.values[i]:"+str(train_df.values[i]))
  # v is an array?
  print((df.Indice[i]))
  v = train_df.values[i][int(df.Indice[i]) :]
  mask = np.abs((v - v.mean(0)) / v.std(0)) > 100
  v = np.where(mask, np.nan, v) # v is target
  t.append((v[:-prediction_length]))
  t2.append(v)

print(df.Indice[i])
import numpy
r=pd.read_json('{"COD_ART_GAM":{"0":0.0,"1":0.0,"2":0.0}}',dtype=numpy.dtype(dc.Decimal))
e= r.COD_ART_GAM
'''
'''


import  kensu.pandas as pd



train_enabled=True
prediction_length = 12

# see https://github.com/mmaithani/data-science/blob/main/Gluonts_twitter_volume_forecasting.ipynb
# added to make training pass
import kensu.pandas as pd
url = "https://raw.githubusercontent.com/numenta/NAB/master/data/realTweets/Twitter_volume_AMZN.csv"
dummy_ts_df = pd.read_csv(url, header=0, index_col=0)

from gluonts.dataset.common import  ListDataset
from gluonts.dataset.field_names import FieldName
from kensu.gluonts.model.deepar import DeepAREstimator
from gluonts.model.n_beats import NBEATSEstimator
from gluonts.model.r_forecast import RForecastPredictor
from gluonts.model.wavenet import WaveNetEstimator
from gluonts.mx.distribution import DistributionOutput, StudentTOutput, NegativeBinomialOutput,GaussianOutput, PiecewiseLinearOutput
from gluonts.mx.trainer import Trainer
from gluonts.evaluation.backtest import make_evaluation_predictions
from tqdm.autonotebook import tqdm
from gluonts.evaluation import Evaluator
from gluonts.evaluation import Evaluator
import mxnet as mx

train_ds = ListDataset([{
    "start": dummy_ts_df.index[0],
    "target": dummy_ts_df.value[:"2015-04-05 00:00:00"]
}],
                          freq="5min")
test_ds=train_ds


estimator = DeepAREstimator(
      prediction_length=prediction_length,
      context_length=prediction_length+4,
      freq="5min", # FIXME: changed
      num_cells =10,
      num_layers=2,
    #  dropout_rate=0.014573972257018428,
      distr_output =NegativeBinomialOutput(),
      # FIXME: use_feat_static_cat=True,
      # FIXME: use_feat_static_real=True,
      # FIXME: cardinality=stat_cat_cardinalities,
      cell_type ='lstm',
      scaling =True
      )

mx.random.seed(7)
import numpy as np
np.random.seed(7)
predictor = estimator.train(test_ds)


forecast_it, ts_it = make_evaluation_predictions(
    dataset=test_ds,
    predictor=predictor,
    num_samples=500
)

tss = list(tqdm(ts_it, total=len(test_ds)))
forecasts = list(tqdm(forecast_it, total=len(test_ds)))
evaluator = Evaluator(quantiles=[0.5, 0.9])
agg_metrics, item_metrics = evaluator(iter(tss), iter(forecasts), num_series=len(test_ds))

import kensu.pandas as pd
url = "https://raw.githubusercontent.com/numenta/NAB/master/data/realTweets/Twitter_volume_AMZN.csv"
dummy_ts_df = pd.read_csv(url, header=0, index_col=0)
res=dummy_ts_df
res.loc[res["value"]==57]

res["value"]==57
'''



KENSU = True


from gluonts.dataset.common import  ListDataset

if KENSU:
  from kensu.gluonts.model.deepar import DeepAREstimator
  from kensu.gluonts.evaluation.backtest import make_evaluation_predictions
  import kensu.pandas as pd
  import kensu.numpy as np

else:
  from gluonts.evaluation.backtest import make_evaluation_predictions
  import pandas as pd
  from gluonts.model.deepar import DeepAREstimator
  import numpy as np

from gluonts.mx.distribution import DistributionOutput, StudentTOutput, NegativeBinomialOutput
from gluonts.mx.trainer import Trainer
import mxnet as mx

#
#

train_enabled=True
prediction_length = 12



url = "https://raw.githubusercontent.com/numenta/NAB/master/data/realTweets/Twitter_volume_AMZN.csv"
dummy_ts_df = pd.read_csv(url, header=0, index_col=0)
# FIXME: here it does NOT use the original train/test DS preparation code!

rrr= dummy_ts_df.value[:"2015-04-05 00:00:00"]

from gluonts.dataset.field_names import FieldName

train_ds = ListDataset([{
    FieldName.START: dummy_ts_df.index[0],
    FieldName.TARGET: rrr
}],
                          freq="5min")
test_ds=train_ds

if train_enabled:
  estimator = DeepAREstimator(
      prediction_length=prediction_length,
      context_length=prediction_length+4,
      freq="5min", # FIXME: changed
      num_cells =10,
      num_layers=2,
    #  dropout_rate=0.014573972257018428,
      distr_output =NegativeBinomialOutput(),
      # FIXME: use_feat_static_cat=True,
      # FIXME: use_feat_static_real=True,
      # FIXME: cardinality=stat_cat_cardinalities,
      cell_type ='lstm',
      scaling =True,
      trainer=Trainer(
        ctx="cpu",
        patience= 44,
        epochs=10,
        num_batches_per_epoch=1,
        learning_rate=0.008756221196907199
      ))

  mx.random.seed(7)
  np.random.seed(7)

  predictor = estimator.train(train_ds)

  # forecast_it, ts_it = make_evaluation_predictions(
  #     dataset=test_ds,
  #     predictor=predictor,
  #     num_samples=5
  # )


  #y = predictor.predict(test_ds, num_samples=5)



  prediction = predictor.predict(Y=test_ds)


  f = []
  item = []
  dt = []


  for p in prediction:
      i = p.mean
      ee=i.round()
      f.append(ee)

      item.append(np.repeat(p.item_id, len(p.mean.round())))
      dt.append(pd.date_range(start=p.start_date, periods=12, freq="W-MON"))



  import kensu.itertools as itertools
  from kensu.itertools import kensu_list
  be=itertools.chain.from_iterable(item)




  
  res = pd.DataFrame(
      {
          "COD_ART_GAM": kensu_list(be),
          "yhat": np.round(kensu_list(itertools.chain.from_iterable(f))),
          "DAT_CPT_STK_MVT": kensu_list(itertools.chain.from_iterable(dt)),
      }
  )
  res.to_csv('res.csv')

