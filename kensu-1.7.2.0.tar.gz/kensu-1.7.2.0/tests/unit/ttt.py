#from kensu.utils.rule_engine import *


def data_prep(data):
    data['education']=np.where(data['education'] =='basic.9y', 'Basic', data['education'])
    data['education']=np.where(data['education'] =='basic.6y', 'Basic', data['education'])
    data['education']=np.where(data['education'] =='basic.4y', 'Basic', data['education'])

    cat = [i for i in ['job','marital','education','default','housing','loan','contact','month','day_of_week','poutcome'] if i in data.columns]

    data_dummy = pd.get_dummies(data,columns=cat)

    features=[i for i in ['euribor3m', 'job_blue-collar', 'job_housemaid', 'marital_unknown',
      'month_apr', 'month_aug', 'month_jul', 'month_jun', 'month_mar',
      'month_may', 'month_nov', 'month_oct', "poutcome_success"] if i in data_dummy.columns]

    data_final = data_dummy[features]
    return data_final


# ingestion_url = "https://playground-api.kensuapp.com"
# ingestion_token = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI2dvb2dsZS1vYXV0aDJ8MTE0OTg0MzE2MTU2NTQ4MTczNzA5IiwidG9rZW5faWQiOiJmMzQ0YzU1Yy1mOTk5LTQ4OGYtOGU5NS1jNzc0ZWNiZTc5MDIiLCJhcHBncm91cF9pZCI6IjdjMzgyMzMxLTBiYjEtNDUyOC1iOGM2LWQwYmJmYTRlN2NmMCIsIiRpbnRfcm9sZXMiOlsiYXBwIl0sImV4cCI6MTkzODA4NjUwMCwiaWF0IjoxNjIyNzI2NTAwfQ.ya-H9KGCyT6Ptq2zaLIwjZno3cDVw9IYonM79WgY7wg"
# PAT = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI2dvb2dsZS1vYXV0aDJ8MTE0OTg0MzE2MTU2NTQ4MTczNzA5LS0tZXh0LWFwcCIsInRva2VuX2lkIjoiNWRhOGVmZTgtMGI1ZS00NjNkLTk2ZTktNGJhNDJhNjUxNjQ5IiwiJGludF9yb2xlcyI6WyJhZG1pbiJdLCJjbiI6IlNhbW15IEVsIEtoYW1tYWwiLCJleHAiOjQ3ODg4Mzc4NzYsImlhdCI6MTYzNTIzNzg3Nn0.P0qJ5SgEF8vjXNDP6ACsyC4FZkk3J3v8CbB30HhHgtY"

# ingestion_token = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI3NhbW15IiwidG9rZW5faWQiOiI1YzRkYTc3My0wZjI5LTRmYzMtOTljOS04MTAzNzlmMTYyNTAiLCJhcHBncm91cF9pZCI6Ijk0YTk3YWY0LTE4ODItNGM3OC05Mzc5LWE2MDczN2JmM2Y5MSIsIiRpbnRfcm9sZXMiOlsiYXBwIl0sImV4cCI6MTk1MjUxNDgwOSwiaWF0IjoxNjM3MTU0ODA5fQ.CyDlNCUjL0iZZybNlTGprL9z4hMflKO9TPpSqxd2PY4"
# ingestion_url = "https://li-livedev-api.464n.com"
# PAT = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI3NhbW15LS0tZXh0LWFwcCIsInRva2VuX2lkIjoiN2Q3ZTYyMDUtY2UzMS00ZDQ0LTkwNzQtOGE4MmExZDAwMWU4IiwiJGludF9yb2xlcyI6WyJhZG1pbiJdLCJjbiI6InNhbW15ICIsImV4cCI6NDc5MDc1NTAxOCwiaWF0IjoxNjM3MTU1MDE4fQ.n_tVtfnNs3plEA9gryjKE3m1023fnmW8M_xJrcCLoaE"

#ingestion_token = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI3NhbW15IiwidG9rZW5faWQiOiI2YjBlZGY2NC1mODMzLTRlYWYtYTQzYy1kMjQyZjU5ZDVlNzkiLCJhcHBncm91cF9pZCI6IjE2YjI5YWFmLWEyNzItNDBhNi05NTZkLWI4MGM2MzYxZDM2OSIsIiRpbnRfcm9sZXMiOlsiYXBwIl0sImV4cCI6MTk1MjkzNDc3NywiaWF0IjoxNjM3NTc0Nzc3fQ.EVWBcjTxCsOiXWtN8zJf5gPDC_d_gvyspxPHiAoS0SI"
#ingestion_url = "https://li-demo2107-he-api.464n.com"
#PAT = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI3NhbW15LS0tZXh0LWFwcCIsInRva2VuX2lkIjoiZGNiMzM3ZjUtOTcwOC00ODZjLWExZjMtYTA2NzQ3MjJjZWQ3IiwiJGludF9yb2xlcyI6WyJhZG1pbiJdLCJjbiI6InNhbW15ICIsImV4cCI6NDc4ODgzNTE3OCwiaWF0IjoxNjM1MjM1MTc4fQ.Pcupx7HRTxFZgaWH0fQrKnEUAycSNTVRHIaV0PdpCds"


ingestion_token = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI2dvb2dsZS1vYXV0aDJ8MTE0OTg0MzE2MTU2NTQ4MTczNzA5IiwidG9rZW5faWQiOiIxZDhhODAyOC1hNmY2LTQyNGYtYmI2OC04YWMyZWFmZWNlMDkiLCJhcHBncm91cF9pZCI6IjU3MThlZTc0LTNkYmItNGM5Yi05ZGRhLTY4ZDJjN2FlZjI2ZSIsIiRpbnRfcm9sZXMiOlsiYXBwIl0sImV4cCI6MTk1MzI3OTc0NSwiaWF0IjoxNjM3OTE5NzQ1fQ.ctGew7S5VkdB6Nxv6gbYCXwdJD7Bpz6RfgzBn5n9ZIs"
ingestion_url = "https://li-qacloud-api.464n.com"




from kensu.utils.kensu_provider import KensuProvider

import urllib3
urllib3.disable_warnings()


import kensu.pandas as pd
import kensu.numpy as np

import kensu.pandas as pd
import kensu.pickle as pk
from kensu.utils.kensu_provider import KensuProvider
k=KensuProvider().instance()
i=1

import kensu.pandas as pd
import kensu.pickle as pk
import datetime
from kensu.utils.kensu_provider import KensuProvider
k=KensuProvider().instance()
i=1

for el in ['may']:
    print("Starting Month %s"%el)
    k = KensuProvider().initKensu(api_url=ingestion_url, auth_token=ingestion_token, process_name='Test c p',
                              user_name='Sammy', code_location='https://gitlab.example.com', init_context=True,
                              do_report=True,
                              report_to_file=False, offline_file_name='kensu-offline-custom-name.txt',
                              project_names=['Bank Marketing p'], pandas_support=True, sklearn_support=False,
                              tensorflow_support=False, bigquery_support=False, pyspark_support=False, compute_delta= True,
                              environment="Lab", mapping=True, report_in_mem=False,
                              raise_on_check_failure = False, logical_naming="File",allow_reinit=True)
    #timestamp=int(datetime.datetime(2021,i,1).timestamp()*1000)
    #i+=1
    #k.kensu_api.api_client.default_headers["X-Entity-Creation-Time"] = timestamp
    #k.timestamp=timestamp
    customers_info = pd.read_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/%s/customers-data.csv'%el)
    contact_info = pd.read_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/%s/contact-data.csv'%el)

    #check_format_consistency("contact-data.csv")
    #check_schema_consistency("contact-data.csv")

    business_info = pd.read_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/%s/business-data.csv'%el)
    customer360 = customers_info.merge(contact_info,on='id')
    month = pd.merge(customer360,business_info)
    month = data_prep(month)

    #add_variability_rule('jan/contact-data.csv',variation=9,months=8)

    #add_missing_value_rules('jan/contact-data.csv',contact_info)
    #check_nrows_consistency()
    month.to_csv('/Users/kensu/Customers/Kensu/Trial/data/predict/data.csv',index=False)

    import time
    #time.sleep(10)



