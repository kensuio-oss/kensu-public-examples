

# json_df = '{"COD_ART_GAM":{"0":"6008477_NOR-SP_W006"},"DT_START":{"0":"2015-02-26 21:42:53"},"COD_ART":{"0":"6008477"},"Indice":{"0":0.0},"COD_GAM":{"0":"NOR-SP"},"COD_SIT":{"0":"W006"},"COD_HIE_ART_001":{"0":123},"COD_HIE_ART_002":{"0":"123123"},"COD_HIE_ART_003":{"0":"123123123123"},"COD_HIE_ART_004":{"0":"123123123123123123123123"},"COD_GRP_MAR":{"0":"somestring"},"LIB_GRP_MAR":{"0":"somestring"},"LIB_HIE_ART_001":{"0":123},"LIB_HIE_ART_002":{"0":123},"LIB_HIE_ART_003":{"0":123},"LIB_HIE_ART_004":{"0":123},"LIB_HIE_ART_005":{"0":123},"LIB_HIE_ART_006":{"0":123},"COD_HIE_ART_005":{"0":"123123123123123123123123123"},"COD_HIE_ART_006":{"0":"123123123123123123123123123123123123123123123123123123"},"COD_MRQ":{"0":"somestring"},"PRX_ACH_NET_OA01":{"0":0.2892030904},"COD_DEV_ACH_OA01":{"0":"PLN"},"COD_SAI":{"0":"somestring"},"COD_FOU_PCP":{"0":"somestring"},"DIA_PNE":{"0":123},"COD_STA_ART":{"0":"somestring"},"2015-02-26":{"0":1718},"2015-02-27":{"0":16184},"2015-02-28":{"0":15812},"2015-03-01":{"0":13574},"2015-03-02":{"0":15017},"2015-03-03":{"0":18956},"2015-03-04":{"0":17869},"2015-03-05":{"0":19890},"2015-03-06":{"0":16818},"2015-03-07":{"0":14239},"2015-03-08":{"0":12875},"2015-03-09":{"0":16324},"2015-03-10":{"0":15928},"2015-03-11":{"0":17465},"2015-03-12":{"0":15970},"2015-03-13":{"0":15277},"2015-03-14":{"0":14857},"2015-03-15":{"0":12282},"2015-03-16":{"0":14742},"2015-03-17":{"0":15635},"2015-03-18":{"0":15575},"2015-03-19":{"0":15233},"2015-03-20":{"0":15472},"2015-03-21":{"0":14370},"2015-03-22":{"0":14683},"2015-03-23":{"0":15233},"2015-03-24":{"0":15522},"2015-03-25":{"0":16582},"2015-03-26":{"0":16686},"2015-03-27":{"0":14209},"2015-03-28":{"0":13390},"2015-03-29":{"0":12701},"2015-03-30":{"0":17019},"2015-03-31":{"0":19106},"2015-04-01":{"0":21400},"2015-04-02":{"0":16082},"2015-04-03":{"0":15316},"2015-04-04":{"0":12771},"2015-04-05":{"0":13101},"2015-04-06":{"0":17586},"2015-04-07":{"0":16328},"2015-04-08":{"0":19394},"2015-04-09":{"0":18143},"2015-04-10":{"0":14228},"2015-04-11":{"0":13669},"2015-04-12":{"0":10941},"2015-04-13":{"0":12894},"2015-04-14":{"0":15541},"2015-04-15":{"0":14325},"2015-04-16":{"0":14299},"2015-04-17":{"0":14106},"2015-04-18":{"0":11699},"2015-04-19":{"0":11647},"2015-04-20":{"0":13993},"2015-04-21":{"0":15974},"2015-04-22":{"0":13118},"country":{"0":"SP"},"bu":{"0":"NOR"}}'
#
# json_train = '{"2015-02-26":{"0":1718},"2015-02-27":{"0":16184},"2015-02-28":{"0":15812},"2015-03-01":{"0":13574},"2015-03-02":{"0":15017},"2015-03-03":{"0":18956},"2015-03-04":{"0":17869},"2015-03-05":{"0":19890},"2015-03-06":{"0":16818},"2015-03-07":{"0":14239},"2015-03-08":{"0":12875},"2015-03-09":{"0":16324},"2015-03-10":{"0":15928},"2015-03-11":{"0":17465},"2015-03-12":{"0":15970},"2015-03-13":{"0":15277},"2015-03-14":{"0":14857},"2015-03-15":{"0":12282},"2015-03-16":{"0":14742},"2015-03-17":{"0":15635},"2015-03-18":{"0":15575},"2015-03-19":{"0":15233},"2015-03-20":{"0":15472},"2015-03-21":{"0":14370},"2015-03-22":{"0":14683},"2015-03-23":{"0":15233},"2015-03-24":{"0":15522},"2015-03-25":{"0":16582},"2015-03-26":{"0":16686},"2015-03-27":{"0":14209},"2015-03-28":{"0":13390},"2015-03-29":{"0":12701},"2015-03-30":{"0":17019},"2015-03-31":{"0":19106},"2015-04-01":{"0":21400},"2015-04-02":{"0":16082},"2015-04-03":{"0":15316},"2015-04-04":{"0":12771},"2015-04-05":{"0":13101},"2015-04-06":{"0":17586},"2015-04-07":{"0":16328},"2015-04-08":{"0":19394},"2015-04-09":{"0":18143},"2015-04-10":{"0":14228},"2015-04-11":{"0":13669},"2015-04-12":{"0":10941},"2015-04-13":{"0":12894},"2015-04-14":{"0":15541},"2015-04-15":{"0":14325},"2015-04-16":{"0":14299},"2015-04-17":{"0":14106},"2015-04-18":{"0":11699},"2015-04-19":{"0":11647},"2015-04-20":{"0":13993},"2015-04-21":{"0":15974},"2015-04-22":{"0":13118}}'
#
#import pandas
# pandas.read_json(json_df).to_csv('df.csv',index=False)
# pandas.read_json(json_train).to_csv('traindf.csv',index=False)

#dummy = pandas.read_csv('https://adb-5854582713150880.0.azuredatabricks.net/files/df.csv?o=5854582713150880')



ingestion_url = "https://playground-api.kensuapp.com"
ingestion_token = "eyJhbGciOiJIUzI1NiJ9.eyIkaW50X3Blcm1zIjpbXSwic3ViIjoib3JnLnBhYzRqLmNvcmUucHJvZmlsZS5Db21tb25Qcm9maWxlI2dvb2dsZS1vYXV0aDJ8MTE0OTg0MzE2MTU2NTQ4MTczNzA5IiwidG9rZW5faWQiOiIxZTg3ZjE1NS1mNDBlLTQ2ZTctODlhZi1mNjIyN2Q3NzllNjAiLCJhcHBncm91cF9pZCI6IjY3ZGRiMGM2LTJiMWUtNDk1OS04YzU1LTNiZDg1ZjgxOTY1ZiIsIiRpbnRfcm9sZXMiOlsiYXBwIl0sImV4cCI6MTkzNjY4NTU4MSwiaWF0IjoxNjIxMzI1NTgxfQ.VRrZvitSPdtVcAK6JP263PSa_7-4JAEH8Z4OWTZVXoM"

from kensu.utils.kensu_provider import KensuProvider

import urllib3
urllib3.disable_warnings()

KENSU = True


from gluonts.dataset.common import  ListDataset

if KENSU:
  from kensu.gluonts.model.deepar import DeepAREstimator
  from kensu.gluonts.evaluation.backtest import make_evaluation_predictions
  import kensu.pandas as pd
  import kensu.numpy as np

else:
  from gluonts.evaluation.backtest import make_evaluation_predictions
  import pandas as pd
  from gluonts.model.deepar import DeepAREstimator
  import numpy as np

from gluonts.mx.distribution import DistributionOutput, StudentTOutput, NegativeBinomialOutput
from gluonts.mx.trainer import Trainer
import mxnet as mx
from gluonts.dataset.field_names import FieldName


dam = KensuProvider().initKensu(api_url=ingestion_url, auth_token=ingestion_token, process_name='Test Gluon',
                            user_name='Sammy', code_location='https://gitlab.example.com', init_context=True, do_report=True,
                            report_to_file=False, offline_file_name='kensu-offline-custom-name.txt',
                            project_names=['Pandas'], pandas_support=True, sklearn_support=False,
                                tensorflow_support=False, bigquery_support=False,pyspark_support=False,
                         environment="Lab",mapping=True,report_in_mem=False,logical_naming='Folder')


df = pd.read_csv('df.csv')

dummy_ts_df1 = pd.read_csv('/Users/kensu/Downloads/df.csv',index_col=0)

df["PRX_ACH_NET_OA01"] = np.where(
    df["COD_DEV_ACH_OA01"] == "PLN",
    df["PRX_ACH_NET_OA01"].astype("float") * 0.22,
    df["PRX_ACH_NET_OA01"].astype("float"),
)
df["country"] = df["COD_GAM"].str[-2:]
df["bu"] = df["COD_GAM"].str[:-3]

# FIXME: kensu_pandas has no pd.date_range

dates = pd.date_range(start="2020-03-16", end="2020-05-15", freq="W-MON")
for d in dates:
    i = d.strftime("%Y-%m-%d")
    if i in df.columns:
        df[i] = df[i].replace(0, np.nan)

dates_close = np.array(["2021-01-11", "2021-01-18"], dtype="str")
for i in dates_close:
    if i in df.columns:
        df[i] = np.where(df["COD_SIT"] == "W006", df[i].replace(0, np.nan), df[i])

COD_ART = df["COD_ART"].astype("category").cat.codes.values
COD_ART_un, COD_MRQ_counts = np.unique(COD_ART, return_counts=True)

COD_MRQ = df["COD_MRQ"].astype("category").cat.codes.values
COD_MRQ_un, COD_MRQ_counts = np.unique(COD_MRQ, return_counts=True)

COD_GAM = df["COD_GAM"].astype("category").cat.codes.values
COD_GAM_un, COD_GAM_counts = np.unique(COD_GAM, return_counts=True)

COD_SIT = df["COD_SIT"].astype("category").cat.codes.values
COD_SIT_un, COD_SIT_counts = np.unique(COD_SIT, return_counts=True)

country = df["country"].astype("category").cat.codes.values
country_un, country_counts = np.unique(country, return_counts=True)

bu = df["bu"].astype("category").cat.codes.values
bu_un, bu_counts = np.unique(bu, return_counts=True)

COD_HIE_ART_002 = df["COD_HIE_ART_002"].astype("category").cat.codes.values
COD_HIE_ART_002_un, COD_HIE_ART_002_counts = np.unique(
    COD_HIE_ART_002, return_counts=True
)

COD_HIE_ART_003 = df["COD_HIE_ART_003"].astype("category").cat.codes.values
COD_HIE_ART_003_un, COD_HIE_ART_003_counts = np.unique(
    COD_HIE_ART_003, return_counts=True
)

COD_HIE_ART_004 = df["COD_HIE_ART_004"].astype("category").cat.codes.values
COD_HIE_ART_004_un, COD_HIE_ART_004_counts = np.unique(
    COD_HIE_ART_004, return_counts=True
)

COD_HIE_ART_005 = df["COD_HIE_ART_003"].astype("category").cat.codes.values
COD_HIE_ART_005_un, COD_HIE_ART_005_counts = np.unique(
    COD_HIE_ART_005, return_counts=True
)

COD_HIE_ART_006 = df["COD_HIE_ART_006"].astype("category").cat.codes.values
COD_HIE_ART_006_un, COD_HIE_ART_006_counts = np.unique(
    COD_HIE_ART_006, return_counts=True
)

COD_SAI = df["COD_SAI"].astype("category").cat.codes.values
COD_SAI_un, COD_SAI_counts = np.unique(COD_SAI, return_counts=True)
#         COD_FOU_PCP = df["COD_FOU_PCP"].astype("category").cat.codes.values
#         COD_FOU_PCP_un, COD_FOU_PCP_counts = np.unique(COD_FOU_PCP, return_counts=True)
DIA_PNE = df["DIA_PNE"].astype("category").cat.codes.values
DIA_PNE_un, DIA_PNE_counts = np.unique(DIA_PNE, return_counts=True)

stat_cat_list = [
    COD_ART,
    COD_MRQ,
    COD_GAM,
    COD_SIT,
    country,
    bu,
    COD_HIE_ART_002,
    COD_HIE_ART_003,
    COD_HIE_ART_004,
    COD_HIE_ART_005,
    COD_HIE_ART_006,
    COD_SAI,
    #             COD_FOU_PCP,
    DIA_PNE,
]

stat_cat = np.concatenate(stat_cat_list)
stat_cat = stat_cat.reshape(len(stat_cat_list), len(COD_MRQ)).T

stat_cat_cardinalities = [
    len(COD_ART_un),
    len(COD_MRQ_un),
    len(COD_GAM_un),
    len(COD_SIT_un),
    len(country_un),
    len(bu_un),
    len(COD_HIE_ART_002_un),
    len(COD_HIE_ART_003_un),
    len(COD_HIE_ART_004_un),
    len(COD_HIE_ART_005_un),
    len(COD_HIE_ART_006_un),
    len(COD_SAI_un),
    #             len(COD_FOU_PCP_un),
    len(DIA_PNE_un),
]

stat_real = (
    np.array(df.PRX_ACH_NET_OA01.astype("float").values).reshape(1, len(COD_GAM)).T
)
train_df = df.drop(
    [
        "COD_ART_GAM",
        "DT_START",
        "COD_ART",
        "COD_MRQ",
        "COD_STA_ART",
        "Indice",
        "COD_GAM",
        "COD_SIT",
        "country",
        "bu",
        "COD_HIE_ART_001",
        "COD_HIE_ART_002",
        "COD_HIE_ART_003",
        "COD_HIE_ART_004",
        "COD_HIE_ART_005",
        "COD_GRP_MAR",
        "LIB_GRP_MAR",
        "LIB_HIE_ART_001",
        "LIB_HIE_ART_002",
        "LIB_HIE_ART_003",
        "LIB_HIE_ART_004",
        "LIB_HIE_ART_005",
        "LIB_HIE_ART_006",
        "COD_SAI",
        "COD_HIE_ART_006",
        "COD_STA_ART",
        "PRX_ACH_NET_OA01",
        "COD_DEV_ACH_OA01",
        "COD_FOU_PCP",
        "DIA_PNE",
    ],
    axis=1,
)

train_df

prediction_length = 12
dates = df.DT_START.values
item_id = df.COD_ART_GAM.values
t = []
t2 = []
for i in range(len(train_df.values)):
    #print("i={}".format(str(i)))
    #print("train_df.values[i]:"+str(train_df.values[i])
    # v is an array?
    v = train_df.values[i] #[int(df.Indice[i]) :]
    mask = np.abs((v - v.mean(0)) / v.std(0)) > 100
    v = np.where(mask, np.nan, v) # v is target
    # FIXME: modified!
    #     "start": dummy_ts_df1.index[0],
    v = dummy_ts_df1.value[:"2015-04-05 00:00:00"]
    t.append((v[:-prediction_length]))
    t2.append(v)
train_target_values = (np.array([e.get_s() for e in t]))

test_target_values = (np.array([e.get_s() for e in t2]))

mx.random.seed(7)
np.random.seed(7)
train_enabled=True

train_ds = ListDataset(
    [
        {
            FieldName.TARGET: target,
            FieldName.ITEM_ID: item_id,
            FieldName.START: dummy_ts_df1.index[0], # FIXME: need valid dates for W freq, start,
            FieldName.FEAT_STATIC_CAT: fsc,
            FieldName.FEAT_STATIC_REAL: fsr,
            # FieldName.FEAT_DYNAMIC_REAL: [fdr]
        }
        for (
            target,
            item_id,
            start,
            fsc,
            fsr
            # , fdr
        ) in zip(
            train_target_values,
            item_id,
            dates,
            stat_cat,
            stat_real,
            # cvs_values
        )
    ],
    freq="W-MON", # FIXME: 5min
)

test_ds = ListDataset(
    [
        {
            FieldName.TARGET: target,
            FieldName.ITEM_ID: item_id,
            FieldName.START: dummy_ts_df1.index[0], # FIXME: need valid dates for W freq, start,
            FieldName.FEAT_STATIC_CAT: fsc,
            FieldName.FEAT_STATIC_REAL: fsr,
            # FieldName.FEAT_DYNAMIC_REAL: [fdr]
        }
        for (
            target,
            item_id,
            start,
            fsc,
            fsr
            #          , fdr
        ) in zip(
            test_target_values,
            item_id,
            dates,
            stat_cat,
            stat_real,
            # cv_values
        )
    ],
    freq="W-MON",
)

train_enabled=True
prediction_length = 12

# see https://github.com/mmaithani/data-science/blob/main/Gluonts_twitter_volume_forecasting.ipynb
# added to make training pass
# import pandas as pd
# url = "https://raw.githubusercontent.com/numenta/NAB/master/data/realTweets/Twitter_volume_AMZN.csv"
# dummy_ts_df = pd.read_csv(url, header=0, index_col=0)
# # FIXME: here it does NOT use the original train/test DS preparation code!
# train_ds = ListDataset([{
#     "start": dummy_ts_df.index[0],
#     "target": dummy_ts_df.value[:"2015-04-05 00:00:00"]
# }],
#                           freq="5min")
# FIXME: changed
#test_ds=train_ds

if train_enabled:
  estimator = DeepAREstimator(
      prediction_length=prediction_length,
      context_length=prediction_length+4,
      freq="W", # FIXME: changed W # 5min
      num_cells =47,
      num_layers=2,
    #  dropout_rate=0.014573972257018428,
      distr_output =NegativeBinomialOutput(),
      use_feat_static_cat=True,
      use_feat_static_real=True,
      cardinality=stat_cat_cardinalities,
      cell_type ='lstm',
      scaling =True,
      trainer=Trainer(
        ctx="cpu",
        patience= 44,
        epochs=10,
        num_batches_per_epoch=1,
        #learning_rate=0.008756221196907199
      ))

  mx.random.seed(7)
  np.random.seed(7)
  predictor = estimator.train(test_ds) # FIXME: it was probably and error here to use test_ds (training_data=train_ds, validation_data=test_ds) # FIXME: changed params slightly
  forecast_it, ts_it = make_evaluation_predictions(
        dataset=test_ds,
        predictor=predictor,
        num_samples=500
  )

  len_series = len(test_ds)
  len_series = 1
  #tss = list(tqdm(ts_it, total=len_series)) #FIXME
  #forecasts = list(tqdm(forecast_it, total=len_series))#len(test_ds)))
  #evaluator = Evaluator(quantiles=[0.5, 0.9])
  #agg_metrics, item_metrics = evaluator(iter(tss), iter(forecasts), num_series=len_series)

  # FIXME: hack below
  if train_enabled:
      prediction = predictor.predict(test_ds)

      f = []
      item = []
      dt = []
      for p in prediction:
          f.append(p.mean.round())
          item.append(np.repeat(p.item_id, len(p.mean.round())))


          dt.append(pd.date_range(start=p.start_date, periods=12, freq="W-MON"))

      import kensu.itertools as itertools
      from kensu.itertools import kensu_list as list

      res = pd.DataFrame(
          {
              "COD_ART_GAM": list(itertools.chain.from_iterable(item)),
              "yhat": np.round(list(itertools.chain.from_iterable(f))),
              "DAT_CPT_STK_MVT": list(itertools.chain.from_iterable(dt)),
          }
      )

      res.to_csv('resfinal3.csv')
